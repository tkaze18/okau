import TelekomLogin from "@/telekom-login"

export default function LoginPage() {
  return <TelekomLogin />
}
